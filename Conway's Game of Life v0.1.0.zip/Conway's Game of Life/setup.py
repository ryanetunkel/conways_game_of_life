install_requires=[
    "pygame>=2.5.1",
]