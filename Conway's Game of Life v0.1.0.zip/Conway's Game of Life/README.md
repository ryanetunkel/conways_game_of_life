A recreation of Conway's Game of Life
